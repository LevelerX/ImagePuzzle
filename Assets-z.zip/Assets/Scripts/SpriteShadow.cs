﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpriteShadow : MonoBehaviour
{
    public Vector2 offset = new Vector2(-0.25f, -0.25f);

    private SpriteRenderer sprRndCaster;
    private SpriteRenderer sprRndShadow;

    private Transform transCaster;
    private Transform transShadow;

    public Material shadowMaterial;
    Color shadowColor;
    // Start is called before the first frame update
    void Start()
    {
        transCaster = transform;
        transShadow = new GameObject().transform;
        transShadow.parent = transCaster;
        transShadow.gameObject.name = "Shadow";
        transShadow.localRotation = Quaternion.identity;

        Vector2 scale = new Vector2(1, 1);
        transShadow.transform.parent = transCaster.transform;
        transShadow.transform.localScale = scale;

        sprRndCaster = GetComponent<SpriteRenderer>();
        sprRndShadow = transShadow.gameObject.AddComponent<SpriteRenderer>();
        

        sprRndShadow.material = shadowMaterial;
        sprRndShadow.color = shadowMaterial.color;
        sprRndShadow.sortingLayerName = sprRndCaster.sortingLayerName;
        sprRndShadow.sortingOrder = sprRndCaster.sortingOrder - 1; 

    }

    // Update is called once per frame
    void Update()
    {
        

        //0.75f hatayera actual value like x halna cha
        transShadow.position = new Vector2(transCaster.position.x - offset.x , transCaster.position.y - offset.y);

        sprRndShadow.sprite = sprRndCaster.sprite;
    }
}
