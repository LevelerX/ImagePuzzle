using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Hint : MonoBehaviour
{

    public Text hint;
    GM GameManager;
    // Start is called before the first frame update
    void Start()
    {
        GameManager = FindObjectOfType<GM>();

        hint = GameObject.Find("Hint").GetComponent<Text>();
    }

    public void AddHint()
    {
       
        hint.text = "HINT : " + GameManager.image.ToString();
    }

    public void HideHint()
    {

        hint.text = "  ";
    }
}
