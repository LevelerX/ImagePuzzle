using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Puzzle : MonoBehaviour
{
    
    /*public int sizeRow, sizeCol;

    int countPoint = 0;

    public List<GameObject> checkPointList; // runs from 0 ---> list.count;
    public List<GameObject> ImageKeyList;
    public List<GameObject> OrgImageList;

    GameObject[,] checkPointMatrix;
    GameObject[,] ImageKeyMatrix;
    GameObject[,] OrgImageMatrix; 




    public Block selectedBlock;

    public Block[,] solvedPuzzle;

    public GameObject[] puzzlePiece;

    Queue<Block> inputs;

    bool blockisMoving;



    void Start()
    {
        
       
       for (int i = 0; i < 9; i++)
        {
            Block block = puzzlePiece[i].gameObject.GetComponent<Block>();
            block.OnBlockPressed += PlayerMoveBlockInput;
            block.OnFinishedMoving += OnBlockFinishedMoving;
        }

        inputs = new Queue<Block>();

        

    }

   /* void CheckPointManager()
    {
        for (int r = 0; r < sizeRow; r++) //runs row
        {
            for (int c = 0; c < sizeCol; c++) //runs column
            {
                checkPointMatrix[r, c] = checkPointList[countPoint];
                countPoint++;
            }
        }
    } */

   /* void ImageKeyManager()
    {
        for (int r = 0; r < sizeRow; r++) //runs row
        {
            for (int c = 0; c < sizeCol; c++) //runs column
            {
                
                ImageKeyMatrix[r, c] = ImageKeyList[countPoint];
                countPoint++;
            }
        }
    } */

    // Update is called once per frame
    void Update()
    {
        /* void ImageOfEasyLevel()
        {
            OrgImageMatrix[0, 0] = OrgImageList[0]; //1st row
            OrgImageMatrix[0, 1] = OrgImageList[2];
            OrgImageMatrix[0, 2] = OrgImageList[5];
            OrgImageMatrix[1, 0] = OrgImageList[4]; //row 2
            OrgImageMatrix[1, 1] = OrgImageList[1];
            OrgImageMatrix[1, 2] = OrgImageList[7];
            OrgImageMatrix[2, 0] = OrgImageList[3]; //row 3
            OrgImageMatrix[2, 1] = OrgImageList[6];
            OrgImageMatrix[2, 2] = OrgImageList[8];
        } */

        

    }
    /*
    void PlayerMoveBlockInput(Block blockToMove)
    {

        inputs.Enqueue(blockToMove);
        MakeNextPlayerMove();

    }

    void MakeNextPlayerMove()
    {
        while (inputs.Count > 0 && !blockisMoving)
        {
            MoveBlock(inputs.Dequeue());
        }
    }
    void MoveBlock(Block blockToMove)
    {
        //if((blockToMove.transform.position - selectedBlock.transform.position).sqrMagnitude == 5.0625)
        {
            Vector2 targetPosition = selectedBlock.transform.position;
            selectedBlock.transform.position = blockToMove.transform.position;
            blockToMove.MovetoPosition(targetPosition, .25f);
            blockisMoving = true;
            Debug.Log("Switched");
            //Debug.Log((blockToMove.transform.position - selectedBlock.transform.position).sqrMagnitude);
        }
    }

    void OnBlockFinishedMoving()
    {
        blockisMoving = false;

        MakeNextPlayerMove();

       
        
    }

    /* void CheckIfSloved()
    {
        for (int i = 0; i < 9; i++)
        {
            if (!puzzlePiece[i].IsAtStartingCoord())
            {
                return;
            }
        }

        selectedBlock.gameObject.SetActive(true);

    } */
    
}
