using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Block : MonoBehaviour
{
    public event System.Action<Block> OnBlockPressed;
    public event System.Action OnFinishedMoving;

    public Vector2Int coord;
    Vector2 startingCoord;

    void Start()
    {
        CreateShadow();
    }

    public void Init(Vector2Int startingCoord, Texture2D image)
    {
        this.startingCoord = startingCoord;
        coord = startingCoord;

        //GetComponent<MeshRenderer>().material.shader = Shader.Find("Unlit/Texture");
        GetComponent<MeshRenderer>().material = Resources.Load<Material>("Block");
        GetComponent<MeshRenderer>().material.mainTexture = image;
    }

    

    public void MovetoPosition(Vector2 target , float duration)
    {
        StartCoroutine(AnimateMove(target, duration));
    }
    
    void OnMouseDown()
    {
        if (OnBlockPressed != null)
        {
            OnBlockPressed(this);
           

        }
    }
    /*void Start()
    {
        startingCoord = this.transform.localPosition;
        Debug.Log(startingCoord);
        coord = startingCoord;
        
    }
    */

    IEnumerator AnimateMove(Vector2 target, float duration)
    {
        Vector2 initialPos = transform.position;
        float percent = 0;

        while(percent < 1)
        {
            percent += Time.deltaTime / duration;
            transform.position = UnityEngine.Vector2.Lerp(initialPos, target, percent);
            yield return null;
        }

        if(OnFinishedMoving != null)
        {
            OnFinishedMoving();
        }
    }

    
    public bool IsAtStartingCoord()
    {
        return coord == startingCoord;
    }


    void CreateShadow()
    {
       
            //SpriteRenderer sptRnd = this.gameObject.AddComponent<SpriteRenderer>();
            this.gameObject.AddComponent<ShadowScript>();
            Material shadow = Resources.Load("Materials/shadow", typeof(Material)) as Material;
            //sptRnd.material = shadow;
        



    }
}
