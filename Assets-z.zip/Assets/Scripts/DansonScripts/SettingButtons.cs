using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SettingButtons : MonoBehaviour
{
    Settings settings;
    [SerializeField]GameObject settingsUI;
    [SerializeField] GameObject globalVolume;

    AudioPlayer audioPlayer;
    
    // Start is called before the first frame update
    void Start()
    {
        settings = FindObjectOfType<Settings>();
        audioPlayer = FindObjectOfType<AudioPlayer>();
    }

    public void ShowUI()
    {
        if(settingsUI == null && globalVolume == null)
        {
            SceneManager.LoadScene(3);
            settings.GetUI().SetActive(true);
        }
        else if ((settingsUI.activeSelf == false && globalVolume.activeSelf == false))
        {
            settingsUI.SetActive(true);
            globalVolume.SetActive(true);
        }


        audioPlayer.PlayTutorial();
        
        
    }

    public void HideUI()
    {
        
        SceneManager.LoadScene(0);
        settings.GetUI().SetActive(false);
        
    }
}
