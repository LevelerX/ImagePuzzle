using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ListAudio : MonoBehaviour
{
    [SerializeField] List<AudioClip> gameSounds = new List<AudioClip>();
    //[SerializeField] AudioSource carSound;
    AudioSource audioSource;
   // [SerializeField] int orderList = 1;

    private void Awake()
    {
        audioSource = GetComponent<AudioSource>();

    }

    public void PlayTutorial()
    {

        audioSource.clip = gameSounds[0];
        audioSource.Play();
    }

  /*  public void ResetOrder()
    {
        orderList = 1;
    }*/

    /*public void CarSound()
    {
        carSound.Play();
    }

    public void StopCarSound()
    {
        carSound.Pause();
    }
    public void PlayOrder()
    {
        audioSource.clip = gameSounds[orderList];
        audioSource.Play();
        Debug.Log(orderList);
        orderList++;
    }*/
}
