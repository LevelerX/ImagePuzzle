using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour
{
    //public static ScoreManager instance;

    
    GM GameManager;

    public Text scoreText;
    //public Text highScoreText;

    


  /*  private void Awake()
    {
        instance = this;
    }*/
    void Start()
    {
        GameManager = FindObjectOfType<GM>();



        scoreText = GameObject.Find("Score").GetComponent<Text>();

        scoreText.text = "Time : " + GameManager.score + " Sec";

    }

    // Update is called once per frame
    void Update()
    {
       /* if(timer == true)
        {
            startScoring();
        }*/
        
    }

}
