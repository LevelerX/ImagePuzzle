using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GM : MonoBehaviour
{

    public Texture2D[] imagelist;

    public Texture2D image;
    public int blocksPerLine = 4;
    public float Spacing = 0.1f;
    public int shuffleLength = 20;
    public float defaultMoveDuration = .2f;
    public float shuffleMoveDuration = .1f;

    

    public enum PuzzleState { Solved, Shuffling,InPlay};
    public PuzzleState state;

    private Vector2 gapLine = Vector2.zero;

    Block swapBlock;
    Block[,] blocks;
    Queue<Block> inputs;
    bool blockIsMoving;
    int shuffleMovesRemaining;
    Vector2Int prevShuffleOffset;

    public float score = 0;



    
    AudioPlayer audioPlayer;
    
    // Start is called before the first frame update
    void Start()
    {

        image = imagelist[Random.Range(0, imagelist.Length)];

        CreatePuzzle();

        
        audioPlayer = FindObjectOfType<AudioPlayer>();

    }

    void Update()
    {
       if(state ==PuzzleState.InPlay)
        {
            score += 1f * Time.deltaTime;
        }
       


        if (state == PuzzleState.Solved && Input.GetKeyDown(KeyCode.Space))
        {
            FindObjectOfType<StartMenu>().Pressed = true;
            StartShuffle();

        }
    }

    void CreatePuzzle()
    {
        blocks = new Block[blocksPerLine, blocksPerLine];
        Texture2D[,] imageSlices = ImageSlicer.GetSlices(image, blocksPerLine);
        for (int y = 0; y < blocksPerLine; y++)
        {
            for (int x = 0; x < blocksPerLine; x++)
            {

                GameObject blockObject = GameObject.CreatePrimitive(PrimitiveType.Quad);

                blockObject.transform.position = -Vector2.one * (blocksPerLine - 1) * .5f + new Vector2(x + gapLine.x, y + gapLine.y);
                blockObject.transform.parent = transform;
                gapLine.x = gapLine.x + Spacing;

                Block block = blockObject.AddComponent<Block>();

                block.OnBlockPressed += PlayerMoveBlockInput;
                block.OnFinishedMoving += OnBlockFinishedMoving;
                block.Init(new Vector2Int(x, y), imageSlices[x, y]);
                blocks[x, y] = block;

                


                if (y == 0 && x == blocksPerLine - 1)
                {
                    // blockObject.GetComponent<SpriteRenderer>().color = Color.blue;
                    
                    swapBlock = block;
                }
            }
            gapLine.x = 0;
            gapLine.y = gapLine.y + Spacing;
        }



        Camera.main.orthographicSize = blocksPerLine * 0.77f;
        inputs = new Queue<Block>();
    }

    void PlayerMoveBlockInput(Block blockToMove)
    {
        if (state == PuzzleState.InPlay)
        {
            inputs.Enqueue(blockToMove);
            MakeNextPlayerMove();
        }

    }

    void MakeNextPlayerMove()
    {
        while (inputs.Count > 0 && !blockIsMoving)
        {
            MoveBlock(inputs.Dequeue() , defaultMoveDuration);
        }
    }

    void MoveBlock(Block blockToMove , float duration)
    {

        blocks[blockToMove.coord.x, blockToMove.coord.y] = swapBlock;
        blocks[swapBlock.coord.x, swapBlock.coord.y] = blockToMove;

        Vector2Int targetCoord = swapBlock.coord;
        swapBlock.coord = blockToMove.coord;
        blockToMove.coord = targetCoord;

        Vector2 targetPosition = swapBlock.transform.position;
        swapBlock.transform.position = blockToMove.transform.position;
        blockToMove.MovetoPosition(targetPosition, duration);
        blockIsMoving = true;

        audioPlayer.PlayShuffle();
    }

    void OnBlockFinishedMoving()
    {
        blockIsMoving = false;
        CheckIfSloved();
        

        if(state == PuzzleState.InPlay)
        {
            MakeNextPlayerMove();
        }
        else if (state == PuzzleState.Shuffling)
        {
            if (shuffleMovesRemaining > 0)
            {
                MakeNextShuffleMove();
            }
            else
            {
                state = PuzzleState.InPlay;
            }
        }

        

    }

    void StartShuffle()
    {
        state = PuzzleState.Shuffling;
        shuffleMovesRemaining = shuffleLength;
        swapBlock.gameObject.SetActive(false);
        MakeNextShuffleMove();
    }

    void MakeNextShuffleMove()
    {
        Vector2Int[] offsets = { new Vector2Int(1 , 0), new Vector2Int(-1, 0), new Vector2Int(0, 1), new Vector2Int(0, -1) };
        int randomIndex = Random.Range(0, offsets.Length);

        for (int i = 0; i < offsets.Length; i++)

        {
            Vector2Int offset = offsets[(randomIndex + i) % offsets.Length];
            if (offset != prevShuffleOffset * -1)
            {
                Vector2Int moveBlockCoord = swapBlock.coord + offset;

                if (moveBlockCoord.x >= 0 && moveBlockCoord.x < blocksPerLine && moveBlockCoord.y >= 0 && moveBlockCoord.y < blocksPerLine)
                {
                    MoveBlock(blocks[moveBlockCoord.x, moveBlockCoord.y] , shuffleMoveDuration);
                    shuffleMovesRemaining--;
                    prevShuffleOffset = offset;
                    break;
                }

            }

        }

    }
    void CheckIfSloved()
    {
        foreach (Block block in blocks)
        {
            

            if (!block.IsAtStartingCoord())
            {
                return;
            }
        }
        state = PuzzleState.Solved;
        swapBlock.gameObject.SetActive(true);


        FindObjectOfType<GameOver>().OnGameOver();
        
        FindObjectOfType<Hint>().HideHint();

        
    }

    


    

    
}
