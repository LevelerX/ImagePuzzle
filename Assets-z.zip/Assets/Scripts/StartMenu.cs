using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class StartMenu : MonoBehaviour
{

    public GameObject[] Puzzle;
    public GameObject Menu;
    public GameObject PressToShuffle;
    public bool Pressed;

    public GameObject hintGO;


    AudioPlayer audioPlayer;


    private void Start()
    {
        audioPlayer = FindObjectOfType<AudioPlayer>();
    }

    private void Update()
    {
        if(Pressed == true)
        {
            
            if (PressToShuffle == null)
            {
                
                return;
            }
            
            PressToShuffle.SetActive(false);
            
            FindObjectOfType<Hint>().AddHint();

        }

    }
    public void MainMenuScreen()
    {
        audioPlayer.PlayTutorial();
        SceneManager.LoadScene(0);
    }

    public void LoadGameMode()
    {
        audioPlayer.PlayTutorial();
        SceneManager.LoadScene(1);


    }

    public void LoadEasyMode()
    {
        audioPlayer.PlayTutorial();
        Menu.SetActive(false);
        Instantiate(Puzzle[0] , new Vector3(0, 0, 0), Quaternion.identity);
        PressToShuffle.SetActive(true);
        hintGO.AddComponent<Hint>();

    }

    public void LoadMediumMode()
    {
        audioPlayer.PlayTutorial();
        Menu.SetActive(false);
        Instantiate(Puzzle[1], new Vector3(0, 0, 0), Quaternion.identity);
        PressToShuffle.SetActive(true);
        hintGO.AddComponent<Hint>();

    }
    public void LoadHardMode()
    {
        audioPlayer.PlayTutorial();
        Menu.SetActive(false);
        Instantiate(Puzzle[2], new Vector3(0, 0, 0), Quaternion.identity);
        PressToShuffle.SetActive(true);
        hintGO.AddComponent<Hint>();
    }
    
    public void Settings()
    {
        SceneManager.LoadScene(3);
    }

   


    public void QuitGame()
    {
        Application.Quit();
        Debug.Log("Quit is true");
    }
}
