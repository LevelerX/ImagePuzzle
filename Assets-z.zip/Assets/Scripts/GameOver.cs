using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class GameOver : MonoBehaviour
{
    // Start is called before the first frame update

    public GameObject gameOverScreen;

    

    
    //bool gameOver;

    void Start()
    {
       
    }



    // Update is called once per frame
    void Update()
    {
        /*if (gameOver)
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {
                SceneManager.LoadScene(0);
            }
        }*/
    }

    public void OnGameOver()
    {
        gameOverScreen.SetActive(true);
        gameOverScreen.AddComponent<ScoreManager>();
        
        GameObject.Find("Hint").SetActive(false);

        //gameOver = true;
    }
}
